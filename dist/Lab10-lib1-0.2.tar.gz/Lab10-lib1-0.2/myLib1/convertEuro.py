
def euro_to_pln(money, kurs):
    pln = money*kurs
    return pln
